# grade-11-unit-1-summative
this is where I will make my summative project for my grade 11 unit 1 computer science course
